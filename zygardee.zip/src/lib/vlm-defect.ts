import ZAI from "z-ai-web-dev-sdk"
import { DEFECT_LIST, type DefectType, type Severity, type PartProfile, type SensitivityConfig } from "@/lib/defects"

// ============================================================================
// Industrial defect detection module — precision-enhanced pipeline.
//
// Pipeline stages:
//   1. Multi-pass ensemble VLM analysis (broad scan + focused refinement
//      passes with part-profile-tailored prompts). Each pass independently
//      detects, classifies, and localizes defects.
//   2. IoU-based Non-Maximum Suppression (NMS) to deduplicate overlapping
//      detections of the same defect type across passes.
//   3. Confidence boosting: when the same defect is found by multiple passes,
//      the merged confidence is raised (ensemble agreement = higher precision).
//   4. Optional golden-template comparison: a known-good reference image is
//      supplied and the VLM performs a deviation analysis to catch anomalies
//      the per-image passes may have missed.
//   5. Sensitivity-based thresholding filters out low-confidence detections.
//
// All stages are server-side and use the z-ai-web-dev-sdk VLM (no client AI).
// ============================================================================

export interface DetectedDefect {
  type: DefectType
  severity: Severity
  confidence: number // 0..1
  bboxX: number // normalized 0..1
  bboxY: number
  bboxW: number
  bboxH: number
  location: string
  description: string
  // Precision metadata
  verified: boolean // true if confirmed by >=2 ensemble passes
  passCount: number // how many passes detected this defect
  sourcePasses: number[] // which passes detected it (indices)
}

export interface PassResult {
  passIndex: number
  passName: string
  defects: DetectedDefect[]
  rawSummary: string
  durationMs: number
  ok: boolean
}

export interface InspectionResult {
  status: "PASS" | "FAIL" | "REVIEW"
  severity: Severity
  confidence: number
  defects: DetectedDefect[]
  summary: string
  processingMs: number
  raw: string
  // Precision pipeline metadata
  pipeline: {
    passes: PassResult[]
    ensembleMerged: number // detections merged by NMS
    verifiedCount: number // defects confirmed by multiple passes
    goldenTemplateUsed: boolean
    goldenDeviations: number
    sensitivity: string
    partProfile: string
    confidenceThreshold: number
    iouThreshold: number
  }
}

// ---------------------------------------------------------------------------
// Prompt construction — part-profile-aware
// ---------------------------------------------------------------------------

function buildProfileVocab(profile: PartProfile): string {
  // Map profile's primary defects to known keys (filter out unknown extras like SHRINKAGE)
  const known = new Set(DEFECT_LIST.map((d) => d.key))
  const primary = profile.primaryDefects.filter((d) => known.has(d))
  // Always include the full vocabulary as fallback, but highlight primaries
  const allKeys = DEFECT_LIST.map((d) => d.key).join(", ")
  const primaryKeys = primary.join(", ")
  return `Primary defect classes for this part type (prioritize these): ${primaryKeys}\nFull recognized vocabulary (use ONLY these exact keys): ${allKeys}`
}

function buildBroadPrompt(profile: PartProfile): string {
  return `You are an expert automated optical inspection (AOI) system operating in an Industry 4.0 smart factory. You are performing PASS 1 — a BROAD SCAN of a manufactured part.

Part context:
- Part type: ${profile.productType}
- Inspection focus areas: ${profile.focusAreas}
- Acceptance criteria: ${profile.acceptanceCriteria}

${buildProfileVocab(profile)}

Severity scale:
- CRITICAL: part must be rejected, safety/function affected (structural crack, missing component, short circuit)
- MAJOR: part likely rejected, clear functional/cosmetic defect
- MINOR: cosmetic or within tolerance, review recommended

Your task: detect, classify, and localize EVERY visible defect. For each, give a normalized bounding box (0,0 = top-left, 1,1 = bottom-right). Be thorough but precise — only report defects you can actually see. If none, return empty defects with status "PASS".

Return ONLY valid JSON (no markdown, no prose):
{
  "status": "PASS" | "FAIL" | "REVIEW",
  "severity": "NONE" | "MINOR" | "MAJOR" | "CRITICAL",
  "confidence": 0.0,
  "summary": "one-sentence pass-1 summary",
  "defects": [
    { "type": "<key>", "severity": "MINOR"|"MAJOR"|"CRITICAL", "confidence": 0.0, "bboxX": 0.0, "bboxY": 0.0, "bboxW": 0.0, "bboxH": 0.0, "location": "region", "description": "concise" }
  ]
}`
}

function buildFocusedPrompt(profile: PartProfile): string {
  return `You are an expert AOI system performing PASS 2 — a FOCUSED REFINEMENT scan of the same manufactured part. Your goal is to VERIFY suspected defects and CATCH any that pass 1 may have missed.

Part context:
- Part type: ${profile.productType}
- Inspection focus areas: ${profile.focusAreas}
- Acceptance criteria: ${profile.acceptanceCriteria}

${buildProfileVocab(profile)}

Focus especially on:
- Small / subtle defects (hairline cracks, micro-porosity, fine scratches, cold solder joints)
- Edge and corner regions where defects commonly form
- Re-verifying borderline cases with precise bounding boxes
- Distinguishing true defects from normal surface texture / acceptable variation

For each defect, give a tight, accurate normalized bounding box. Be precise — do NOT report a defect unless you are confident it is real. If the part is clean, return empty defects with status "PASS".

Return ONLY valid JSON (no markdown, no prose):
{
  "status": "PASS" | "FAIL" | "REVIEW",
  "severity": "NONE" | "MINOR" | "MAJOR" | "CRITICAL",
  "confidence": 0.0,
  "summary": "one-sentence pass-2 summary",
  "defects": [
    { "type": "<key>", "severity": "MINOR"|"MAJOR"|"CRITICAL", "confidence": 0.0, "bboxX": 0.0, "bboxY": 0.0, "bboxW": 0.0, "bboxH": 0.0, "location": "region", "description": "concise" }
  ]
}`
}

function buildDeepPrompt(profile: PartProfile): string {
  return `You are an expert AOI system performing PASS 3 — a DEEP ANOMALY scan. Look for ANY deviation from a perfect part, including subtle/low-contrast defects that easy to overlook.

Part context:
- Part type: ${profile.productType}
- Inspection focus areas: ${profile.focusAreas}

${buildProfileVocab(profile)}

Look specifically for: faint discoloration gradients, microscopic porosity, barely-visible hairline cracks, light contamination residue, minor geometric deviations. Report even low-confidence suspicions — they will be filtered downstream.

Return ONLY valid JSON (no markdown, no prose):
{
  "status": "PASS" | "FAIL" | "REVIEW",
  "severity": "NONE" | "MINOR" | "MAJOR" | "CRITICAL",
  "confidence": 0.0,
  "summary": "one-sentence pass-3 summary",
  "defects": [
    { "type": "<key>", "severity": "MINOR"|"MAJOR"|"CRITICAL", "confidence": 0.0, "bboxX": 0.0, "bboxY": 0.0, "bboxW": 0.0, "bboxH": 0.0, "location": "region", "description": "concise" }
  ]
}`
}

function buildGoldenPrompt(profile: PartProfile): string {
  return `You are an expert AOI system performing a GOLDEN-TEMPLATE DEVIATION ANALYSIS.

You are given TWO images:
- Image 1: the GOLDEN (known-good reference) part.
- Image 2: the TEST part under inspection.

Part type: ${profile.productType}
Inspection focus areas: ${profile.focusAreas}

Your task: compare the test image against the golden reference. Identify EVERY deviation — any difference that indicates a defect, anomaly, or quality regression in the test part. This catches defects that single-image analysis may miss.

${buildProfileVocab(profile)}

For each deviation, give a normalized bounding box RELATIVE TO THE TEST IMAGE (image 2). Classify the deviation type using the vocabulary above.

Return ONLY valid JSON (no markdown, no prose):
{
  "status": "PASS" | "FAIL" | "REVIEW",
  "severity": "NONE" | "MINOR" | "MAJOR" | "CRITICAL",
  "confidence": 0.0,
  "summary": "one-sentence deviation summary",
  "defects": [
    { "type": "<key>", "severity": "MINOR"|"MAJOR"|"CRITICAL", "confidence": 0.0, "bboxX": 0.0, "bboxY": 0.0, "bboxW": 0.0, "bboxH": 0.0, "location": "region on test image", "description": "deviation from golden" }
  ]
}`
}

// ---------------------------------------------------------------------------
// Parsing & normalization
// ---------------------------------------------------------------------------

function safeParseJSON(text: string): any | null {
  let t = text.trim()
  const fence = t.match(/```(?:json)?\s*([\s\S]*?)```/i)
  if (fence) t = fence[1].trim()
  const start = t.indexOf("{")
  const end = t.lastIndexOf("}")
  if (start !== -1 && end !== -1 && end > start) t = t.slice(start, end + 1)
  try {
    return JSON.parse(t)
  } catch {
    return null
  }
}

const KNOWN_KEYS = new Set(DEFECT_LIST.map((d) => d.key))
// Map common free-form defect names to our taxonomy
const ALIAS_MAP: Record<string, DefectType> = {
  SHRINKAGE: "POROSITY",
  SHRINKAGE_CAVITY: "POROSITY",
  INCLUSION: "POROSITY",
  COLD_SHUT: "CRACK",
  LAP: "CRACK",
  FOLD: "CRACK",
  HAIRLINE: "CRACK",
  DELAMINATION: "WARPING",
  BLISTER: "POROSITY",
  VOID: "POROSITY",
  PINHOLE: "POROSITY",
  SOLDER_BRIDGE: "SHORT_CIRCUIT",
  BRIDGE: "SHORT_CIRCUIT",
  COLD_JOINT: "SHORT_CIRCUIT",
  TOMBSTONE: "MISALIGNMENT",
  MISSING_PART: "MISSING_COMPONENT",
  ABSENT: "MISSING_COMPONENT",
  RUST: "CORROSION",
  PITTING: "CORROSION",
  SCALE: "DISCOLORATION",
  TARNISH: "DISCOLORATION",
  BURN: "DISCOLORATION",
  FLASH: "BURR",
  DIE_LINE: "SCRATCH",
  SCORE: "SCRATCH",
  CHIP: "DENT",
  BOW: "WARPING",
  TWIST: "WARPING",
  SINK: "DENT",
  RESIDUE: "CONTAMINATION",
  FOREIGN_MATERIAL: "CONTAMINATION",
}

function normalizeType(raw: string): DefectType | null {
  const upper = String(raw ?? "").toUpperCase().replace(/[\s-]+/g, "_")
  if (KNOWN_KEYS.has(upper as DefectType)) return upper as DefectType
  if (ALIAS_MAP[upper]) return ALIAS_MAP[upper]
  // try plural/singular
  for (const k of KNOWN_KEYS) {
    if (upper.startsWith(k) || k.startsWith(upper)) return k as DefectType
  }
  return null
}

function normalizeDefect(d: any, passIndex: number): DetectedDefect | null {
  const type = normalizeType(d?.type)
  if (!type) return null
  const severity = String(d?.severity ?? "MINOR").toUpperCase() as Severity
  const sev: Severity = ["MINOR", "MAJOR", "CRITICAL"].includes(severity) ? severity : "MINOR"
  const confidence = Math.max(0, Math.min(1, Number(d?.confidence ?? 0.7) || 0.7))
  const clamp = (v: number) => Math.max(0, Math.min(1, Number(v) || 0))
  return {
    type,
    severity: sev,
    confidence,
    bboxX: clamp(d?.bboxX),
    bboxY: clamp(d?.bboxY),
    bboxW: Math.max(0.02, clamp(d?.bboxW) || 0.1),
    bboxH: Math.max(0.02, clamp(d?.bboxH) || 0.1),
    location: String(d?.location ?? "unspecified region"),
    description: String(d?.description ?? `${type} detected`),
    verified: false,
    passCount: 1,
    sourcePasses: [passIndex],
  }
}

// ---------------------------------------------------------------------------
// IoU-based Non-Maximum Suppression + ensemble merging
// ---------------------------------------------------------------------------

function iou(a: DetectedDefect, b: DetectedDefect): number {
  const ax2 = a.bboxX + a.bboxW
  const ay2 = a.bboxY + a.bboxH
  const bx2 = b.bboxX + b.bboxW
  const by2 = b.bboxY + b.bboxH
  const ix1 = Math.max(a.bboxX, b.bboxX)
  const iy1 = Math.max(a.bboxY, b.bboxY)
  const ix2 = Math.min(ax2, bx2)
  const iy2 = Math.min(ay2, by2)
  const iw = Math.max(0, ix2 - ix1)
  const ih = Math.max(0, iy2 - iy1)
  const inter = iw * ih
  const ua = a.bboxW * a.bboxH + b.bboxW * b.bboxH - inter
  return ua > 0 ? inter / ua : 0
}

function mergeTwo(a: DetectedDefect, b: DetectedDefect): DetectedDefect {
  // Merge two overlapping detections of the same type.
  // Confidence is boosted via ensemble agreement: more passes = higher trust.
  const totalPasses = a.passCount + b.passCount
  // Weighted average by confidence, plus a verification boost
  const sumW = a.confidence + b.confidence
  const avgConf = sumW > 0 ? (a.confidence * a.confidence + b.confidence * b.confidence) / sumW : (a.confidence + b.confidence) / 2
  // Boost: detections confirmed by 2+ passes get up to +0.15
  const boost = totalPasses >= 3 ? 0.18 : totalPasses === 2 ? 0.12 : 0
  const mergedConf = Math.min(0.99, avgConf + boost)

  // Take the more-severe severity (defensive — don't under-report)
  const sevRank: Record<Severity, number> = { NONE: 0, MINOR: 1, MAJOR: 2, CRITICAL: 3 }
  const severity = sevRank[a.severity] >= sevRank[b.severity] ? a.severity : b.severity

  // Union bounding box (covers the full extent of both detections)
  const x1 = Math.min(a.bboxX, b.bboxX)
  const y1 = Math.min(a.bboxY, b.bboxY)
  const x2 = Math.max(a.bboxX + a.bboxW, b.bboxX + b.bboxW)
  const y2 = Math.max(a.bboxY + a.bboxH, b.bboxY + b.bboxH)

  return {
    type: a.type,
    severity,
    confidence: Number(mergedConf.toFixed(3)),
    bboxX: Number(x1.toFixed(4)),
    bboxY: Number(y1.toFixed(4)),
    bboxW: Number((x2 - x1).toFixed(4)),
    bboxH: Number((y2 - y1).toFixed(4)),
    location: a.location || b.location,
    description: a.description.length >= b.description.length ? a.description : b.description,
    verified: totalPasses >= 2,
    passCount: totalPasses,
    sourcePasses: [...a.sourcePasses, ...b.sourcePasses],
  }
}

function ensembleMerge(allDefects: DetectedDefect[], iouThreshold: number): { merged: DetectedDefect[]; mergedCount: number } {
  // Group by defect type first
  const byType: Record<string, DetectedDefect[]> = {}
  for (const d of allDefects) {
    if (!byType[d.type]) byType[d.type] = []
    byType[d.type].push(d)
  }

  const result: DetectedDefect[] = []
  let mergedCount = 0

  for (const type of Object.keys(byType)) {
    let group = byType[type].slice()
    // Sort by confidence descending — keep the strongest as anchors
    group.sort((a, b) => b.confidence - a.confidence)
    const kept: DetectedDefect[] = []
    while (group.length) {
      const anchor = group.shift()!
      const remaining: DetectedDefect[] = []
      for (const d of group) {
        if (iou(anchor, d) >= iouThreshold) {
          // Merge into anchor
          mergedCount++
          Object.assign(anchor, mergeTwo(anchor, d))
        } else {
          remaining.push(d)
        }
      }
      kept.push(anchor)
      group = remaining
    }
    result.push(...kept)
  }

  return { merged: result, mergedCount }
}

// ---------------------------------------------------------------------------
// VLM call helper
// ---------------------------------------------------------------------------

async function vlmAnalyze(
  zai: any,
  prompt: string,
  images: { url: string }[],
  passIndex: number,
  passName: string
): Promise<PassResult> {
  const startedAt = Date.now()
  try {
    const response = await zai.chat.completions.createVision({
      messages: [
        {
          role: "user",
          content: [
            { type: "text", text: prompt },
            ...images.map((img) => ({ type: "image_url" as const, image_url: { url: img.url } })),
          ],
        },
      ],
      thinking: { type: "disabled" },
    })
    const raw = response.choices?.[0]?.message?.content ?? ""
    const parsed = safeParseJSON(raw)
    const durationMs = Date.now() - startedAt
    if (!parsed) {
      return {
        passIndex, passName, durationMs, ok: false,
        defects: [],
        rawSummary: raw.slice(0, 200) || "unstructured response",
      }
    }
    const rawDefects = Array.isArray(parsed.defects) ? parsed.defects : []
    const defects = rawDefects.map((d: any) => normalizeDefect(d, passIndex)).filter(Boolean) as DetectedDefect[]
    return {
      passIndex, passName, durationMs, ok: true,
      defects,
      rawSummary: String(parsed.summary ?? `${defects.length} defect(s)`),
    }
  } catch (e: any) {
    return {
      passIndex, passName, durationMs: Date.now() - startedAt, ok: false,
      defects: [],
      rawSummary: `pass failed: ${e?.message || "unknown error"}`,
    }
  }
}

// ---------------------------------------------------------------------------
// Main entry point
// ---------------------------------------------------------------------------

export interface RunOptions {
  profile: PartProfile
  sensitivity: SensitivityConfig
  goldenTemplateUrl?: string | null // data URL of the reference image
  enabledDefectTypes?: DefectType[] | null // null = all types enabled
}

export async function runDefectDetection(
  imageDataUrl: string,
  opts: RunOptions
): Promise<InspectionResult> {
  const startedAt = Date.now()
  const zai = await ZAI.create()
  const { profile, sensitivity, goldenTemplateUrl, enabledDefectTypes } = opts

  const passes: PassResult[] = []

  // --- Pass 1: Broad scan (always) ---
  passes.push(await vlmAnalyze(zai, buildBroadPrompt(profile), [{ url: imageDataUrl }], 0, "Broad Scan"))

  // --- Pass 2: Focused refinement (strict + balanced + sensitive) ---
  if (sensitivity.ensemblePasses >= 2) {
    passes.push(await vlmAnalyze(zai, buildFocusedPrompt(profile), [{ url: imageDataUrl }], 1, "Focused Refinement"))
  }

  // --- Pass 3: Deep anomaly (sensitive only) ---
  if (sensitivity.ensemblePasses >= 3) {
    passes.push(await vlmAnalyze(zai, buildDeepPrompt(profile), [{ url: imageDataUrl }], 2, "Deep Anomaly"))
  }

  // --- Golden-template comparison (optional) ---
  let goldenDeviations = 0
  if (goldenTemplateUrl) {
    const goldenPass = await vlmAnalyze(
      zai,
      buildGoldenPrompt(profile),
      [{ url: goldenTemplateUrl }, { url: imageDataUrl }],
      passes.length,
      "Golden-Template Deviation"
    )
    passes.push(goldenPass)
    goldenDeviations = goldenPass.defects.length
  }

  // --- Collect all detections across passes ---
  const allDefects = passes.flatMap((p) => p.defects)

  // --- Ensemble merge with NMS ---
  const { merged, mergedCount } = ensembleMerge(allDefects, sensitivity.iouThreshold)

  // --- Apply sensitivity threshold + defect-type filter ---
  const filtered = merged.filter((d) => {
    if (d.confidence < sensitivity.confidenceThreshold) return false
    if (enabledDefectTypes && enabledDefectTypes.length && !enabledDefectTypes.includes(d.type)) return false
    return true
  })

  // --- Re-mark verification (>=2 source passes) ---
  for (const d of filtered) d.verified = d.passCount >= 2

  // --- Compute overall confidence ---
  const verifiedCount = filtered.filter((d) => d.verified).length
  const overallConfidence =
    filtered.length > 0
      ? filtered.reduce((s, d) => s + d.confidence, 0) / filtered.length
      : Math.max(0.9, 1 - (passes.filter((p) => !p.ok).length / passes.length) * 0.2)

  // --- Determine status & severity ---
  let status: "PASS" | "FAIL" | "REVIEW"
  let severity: Severity
  if (filtered.length === 0) {
    status = "PASS"
    severity = "NONE"
  } else {
    const hasCritical = filtered.some((d) => d.severity === "CRITICAL")
    const hasMajor = filtered.some((d) => d.severity === "MAJOR")
    if (hasCritical) { status = "FAIL"; severity = "CRITICAL" }
    else if (hasMajor) { status = "FAIL"; severity = "MAJOR" }
    else if (filtered.length >= 3) { status = "REVIEW"; severity = "MAJOR" }
    else { status = "REVIEW"; severity = "MINOR" }
  }

  // --- Build summary ---
  const passSummaries = passes.map((p) => `${p.passName}: ${p.rawSummary}`).join(" | ")
  const summary = filtered.length === 0
    ? `No defects detected across ${passes.length} ensemble passes. ${goldenTemplateUrl ? "Golden-template comparison confirmed no deviations." : ""}`
    : `${filtered.length} defect(s) confirmed across ${passes.length} ensemble passes (${verifiedCount} verified by multiple passes, ${mergedCount} merged by NMS). ${goldenTemplateUrl ? `Golden-template analysis found ${goldenDeviations} deviation(s).` : ""}`

  const processingMs = Date.now() - startedAt

  return {
    status,
    severity,
    confidence: Number(overallConfidence.toFixed(3)),
    defects: filtered,
    summary,
    processingMs,
    raw: passSummaries,
    pipeline: {
      passes,
      ensembleMerged: mergedCount,
      verifiedCount,
      goldenTemplateUsed: !!goldenTemplateUrl,
      goldenDeviations,
      sensitivity: sensitivity.key,
      partProfile: profile.key,
      confidenceThreshold: sensitivity.confidenceThreshold,
      iouThreshold: sensitivity.iouThreshold,
    },
  }
}
